-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: library
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publication_year` int(11) DEFAULT NULL,
  `available` tinyint(1) DEFAULT 1,
  `genre` varchar(100) DEFAULT NULL,
  `added_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (74,'The Great Gatsby','F. Scott Fitzgerald',1925,1,'Novel','2024-10-05 00:00:00'),(75,'To Kill a Mockingbird','Harper Lee',1960,1,'Fiction','2024-10-05 00:00:00'),(76,'1984','George Orwell',1949,0,'Dystopian','2024-10-05 00:00:00'),(77,'Moby Dick','Herman Melville',1851,0,'Adventure','2024-10-05 00:00:00'),(78,'Pride and Prejudice','Jane Austen',1813,0,'Romance','2024-10-05 00:00:00'),(79,'The Catcher in the Rye','J.D. Salinger',1951,0,'Fiction','2024-10-05 00:00:00'),(80,'The Hobbit','J.R.R. Tolkien',1937,1,'Fantasy','2024-10-05 00:00:00'),(81,'War and Peace','Leo Tolstoy',1869,0,'Historical Fiction','2024-10-05 00:00:00'),(82,'Brave New World','Aldous Huxley',1932,0,'Dystopian','2024-10-05 00:00:00'),(83,'Ulysses','James Joyce',1922,1,'Modernist','2024-10-05 00:00:00'),(84,'Crime and Punishment','Fyodor Dostoevsky',1866,0,'Psychological Fiction','2024-10-05 00:00:00'),(85,'Wuthering Heights','Emily Brontë',1847,1,'Gothic Fiction','2024-10-05 00:00:00'),(86,'The Lord of the Rings','J.R.R. Tolkien',1954,1,'Fantasy','2024-10-05 00:00:00'),(87,'The Brothers Karamazov','Fyodor Dostoevsky',1880,1,'Philosophical Fiction','2024-10-05 00:00:00'),(90,'To Kill a Mockingbird','Harper Lee',1960,1,'Fiction','2024-10-05 00:00:00'),(91,'1984','George Orwell',1949,0,'Dystopian','2024-10-05 00:00:00'),(92,'Moby Dick','Herman Melville',1851,1,'Adventure','2024-10-05 00:00:00'),(93,'Pride and Prejudice','Jane Austen',1813,0,'Romance','2024-10-05 00:00:00'),(94,'The Catcher in the Rye','J.D. Salinger',1951,0,'Fiction','2024-10-05 00:00:00'),(95,'The Hobbit','J.R.R. Tolkien',1937,1,'Fantasy','2024-10-05 00:00:00'),(96,'War and Peace','Leo Tolstoy',1869,0,'Historical Fiction','2024-10-05 00:00:00'),(97,'Brave New World','Aldous Huxley',1932,0,'Dystopian','2024-10-05 00:00:00'),(98,'Ulysses','James Joyce',1922,1,'Modernist','2024-10-05 00:00:00'),(99,'To Kill a Mockingbird','Harper Lee',1960,1,'Fiction','2024-10-05 00:00:00'),(100,'1984','George Orwell',1949,0,'Dystopian','2024-10-05 00:00:00'),(101,'Moby Dick','Herman Melville',1851,1,'Adventure','2024-10-05 00:00:00'),(102,'Pride and Prejudice','Jane Austen',1813,0,'Romance','2024-10-05 00:00:00'),(103,'The Catcher in the Rye','J.D. Salinger',1951,0,'Fiction','2024-10-05 00:00:00'),(104,'The Hobbit','J.R.R. Tolkien',1937,1,'Fantasy','2024-10-05 00:00:00'),(105,'War and Peace','Leo Tolstoy',1869,0,'Historical Fiction','2024-10-05 00:00:00'),(106,'Brave New World','Aldous Huxley',1932,0,'Dystopian','2024-10-05 00:00:00'),(107,'Ulysses','James Joyce',1922,1,'Modernist','2024-10-05 00:00:00'),(108,'The Brothers Karamazov','Fyodor Dostoevsky',1880,1,'Philosophical Fiction','2024-10-05 00:00:00');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-24 11:43:52

module org.databasefinal {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql; // Required for JDBC functionality

    opens org.databasefinal to javafx.fxml; // Allows JavaFX to access FXML files
    exports org.databasefinal; // Exports the package for other modules
}

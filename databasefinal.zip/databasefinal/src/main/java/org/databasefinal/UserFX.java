package org.databasefinal;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;

public class UserFX extends Application {
    private TextField nameField;
    private TextField emailField;
    private PasswordField passwordField;
    private Button loginButton;
    private Button searchBooksButton;
    private Button borrowBookButton;
    private ListView<String> searchResults;
    private Button userAccountButton;
    private User currentUser;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bibliotekssystem");

        // Registration/Login Fields
        nameField = new TextField();
        nameField.setPromptText("Fullständigt namn");

        emailField = new TextField();
        emailField.setPromptText("E-post");

        passwordField = new PasswordField();
        passwordField.setPromptText("Lösenord");

        Button registerButton = new Button("Registrera");
        registerButton.setOnAction(e -> registerUser());

        loginButton = new Button("Logga in");
        loginButton.setOnAction(e -> loginUser());

        searchBooksButton = new Button("Sök Böcker");
        searchBooksButton.setOnAction(e -> searchBooks());

        searchResults = new ListView<>();

        borrowBookButton = new Button("Låna vald bok");
        borrowBookButton.setOnAction(e -> borrowBook());

        userAccountButton = new Button("Visa Användarkonto");
        userAccountButton.setOnAction(e -> showUserAccount());

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(
                new Label("Registrera eller Logga in"),
                new Label("Fullständigt namn"), nameField,
                new Label("E-post"), emailField,
                new Label("Lösenord"), passwordField,
                registerButton, loginButton,
                new Label("Sök Böcker"), searchBooksButton, searchResults,
                borrowBookButton,
                userAccountButton
        );

        Scene scene = new Scene(layout, 400, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void registerUser() {
        String fullName = nameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "")) {
            String sql = "INSERT INTO users (full_name, email, password, date_created, last_updated) VALUES (?, ?, ?, NOW(), NOW())";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, fullName);
            statement.setString(2, email);
            statement.setString(3, password);

            int result = statement.executeUpdate();

            if (result > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Registrering lyckades!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Misslyckades med registreringen.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Misslyckades med att registrera användaren: " + e.getMessage());
        }
    }

    private void loginUser() {
        String email = emailField.getText();
        String password = passwordField.getText();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "")) {
            String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, email);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                currentUser = new User();
                currentUser.setUserId(resultSet.getInt("id"));
                currentUser.setFullName(resultSet.getString("full_name"));
                currentUser.setEmail(resultSet.getString("email"));
                showAlert(Alert.AlertType.INFORMATION, "Success", "Inloggning lyckades!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Fel e-post eller lösenord.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Misslyckades med att logga in: " + e.getMessage());
        }
    }

    private void searchBooks() {
        searchResults.getItems().clear();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "")) {
            String sql = "SELECT id, title, author FROM books WHERE available = 1 ORDER BY title";
            PreparedStatement statement = connection.prepareStatement(sql);

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String book = resultSet.getInt("id") + ": " + resultSet.getString("title") + " by " + resultSet.getString("author");
                searchResults.getItems().add(book);
            }

            if (searchResults.getItems().isEmpty()) {
                showAlert(Alert.AlertType.INFORMATION, "No Results", "Inga tillgängliga böcker hittades.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Misslyckades med att söka böcker: " + e.getMessage());
        }
    }

    private void borrowBook() {
        if (currentUser == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Du måste logga in först.");
            return;
        }

        String selectedBook = searchResults.getSelectionModel().getSelectedItem();
        if (selectedBook == null) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Välj en bok att låna.");
            return;
        }

        int bookId = Integer.parseInt(selectedBook.split(":")[0]);
        LocalDate returnDate = LocalDate.now().plusDays(30);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "")) {
            String sql = "INSERT INTO loan (user_id, book_id, loan_date, return_date, status) VALUES (?, ?, CURRENT_DATE, ?, 'borrowed')";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, currentUser.getUserId());
            statement.setInt(2, bookId);
            statement.setDate(3, Date.valueOf(returnDate));

            int result = statement.executeUpdate();

            if (result > 0) {
                String updateBookSql = "UPDATE books SET available = 0 WHERE id = ?";
                PreparedStatement updateBookStatement = connection.prepareStatement(updateBookSql);
                updateBookStatement.setInt(1, bookId);
                updateBookStatement.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Du har lånat: " + selectedBook + "\nÅterlämningsdatum: " + returnDate);
                searchResults.getItems().remove(selectedBook);
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Misslyckades med att låna boken.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Misslyckades med att låna boken: " + e.getMessage());
        }
    }

    private void showUserAccount() {
        if (currentUser == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Du måste logga in först.");
            return;
        }

        StringBuilder userInfo = new StringBuilder("Användarkonto:\nNamn: " + currentUser.getFullName() + "\nE-post: " + currentUser.getEmail() + "\nLånade böcker:\n");

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "")) {
            String sql = "SELECT b.title, l.return_date FROM loan l JOIN books b ON l.book_id = b.id WHERE l.user_id = ? AND l.status = 'borrowed'";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, currentUser.getUserId());

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String book = resultSet.getString("title") + " - Återlämningsdatum: " + resultSet.getDate("return_date");
                userInfo.append(book).append("\n");
            }

            showAlert(Alert.AlertType.INFORMATION, "Användarkonto", userInfo.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Misslyckades med att hämta användarkontoinformation: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

class User {
    private int userId;
    private String fullName;
    private String email;

    public User(int i, String johnDoe, String email) {
    }

    public User() {

    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
